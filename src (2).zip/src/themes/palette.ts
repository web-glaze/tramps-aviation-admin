import { PaletteMode } from '@mui/material';

// ✅ FIX: @ant-design/colors v8 ne presetPalettes ka format badla.
// aur double createTheme() call hata diya — ab sirf plain palette object return hoga.

const blue   = ['#e6f4ff','#bae0ff','#91caff','#69b1ff','#4096ff','#1677ff','#0958d9','#003eb3','#002c8c','#001d66'];
const gold   = ['#fffbe6','#fff1b8','#ffe58f','#ffd666','#ffc53d','#faad14','#d48806','#ad6800','#874d00','#613400'];
const red    = ['#fff1f0','#ffccc7','#ffa39e','#ff7875','#ff4d4f','#f5222d','#cf1322','#a8071a','#820014','#5c0011'];
const cyan   = ['#e6fffb','#b5f5ec','#87e8de','#5cdbd3','#36cfc9','#13c2c2','#08979c','#006d75','#00474f','#002329'];
const green  = ['#f6ffed','#d9f7be','#b7eb8f','#95de64','#73d13d','#52c41a','#389e0d','#237804','#135200','#092b00'];

const greyPrimary  = ['#ffffff','#fafafa','#f5f5f5','#f0f0f0','#d9d9d9','#bfbfbf','#8c8c8c','#595959','#262626','#141414','#000000'];
const greyAscent   = ['#fafafa','#bfbfbf','#434343','#1f1f1f'];
const greyConstant = ['#fafafb','#e6ebf1'];
const grey = [...greyPrimary, ...greyAscent, ...greyConstant];

// Plain palette object return karo — createTheme yahan mat karo
const Palette = (mode: PaletteMode) => ({
  mode,
  common: { black: '#000', white: '#fff' },
  primary: {
    lighter:      blue[0],
    light:        blue[2],
    main:         blue[5],
    dark:         blue[7],
    darker:       blue[9],
    contrastText: '#fff',
  },
  secondary: {
    lighter:      gold[0],
    light:        gold[3],
    main:         gold[5],
    dark:         gold[7],
    darker:       gold[9],
    contrastText: '#fff',
  },
  error:   { lighter: red[0],   light: red[2],   main: red[5],   dark: red[7],   darker: red[9],   contrastText: '#fff' },
  warning: { lighter: gold[0],  light: gold[3],  main: gold[5],  dark: gold[7],  darker: gold[9],  contrastText: '#fff' },
  info:    { lighter: cyan[0],  light: cyan[3],  main: cyan[5],  dark: cyan[7],  darker: cyan[9],  contrastText: '#fff' },
  success: { lighter: green[0], light: green[3], main: green[5], dark: green[7], darker: green[9], contrastText: '#fff' },
  grey,
  text: {
    primary:   grey[7],   // #595959
    secondary: grey[5],   // #bfbfbf
    disabled:  grey[4],   // #d9d9d9
  },
  action:     { disabled: grey[3] },
  divider:    grey[2],
  background: { paper: grey[0], default: grey[1] },
});

export default Palette;